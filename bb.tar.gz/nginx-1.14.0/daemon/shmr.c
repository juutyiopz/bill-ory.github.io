#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#include <sys/types.h>
#include <utmp.h>
#include <pwd.h>
#include <stdio.h>


void getuser() {
    struct passwd *buffer;
    struct utmp *naveen;

    /*
    while (NULL != (buffer = getpwent())) {
        printf("%s %s\n", buffer->pw_name, buffer->pw_passwd);
        //printf("%s", naveen->ut_user);
    }
    endpwent();
    */

    struct utmp *u;
    while ((u=getutent())){
        printf("enter: %d %s\n", u->ut_type, u->ut_user);
        if (u->ut_type == USER_PROCESS) {
            printf("%s\n", u->ut_user);
        }
    }
    endutent();
}

int main()
{
    //getuser();

    key_t key = ftok("/usr/bin/man", 59231);

    int shmid = shmget(key, 0, 0);
    if(-1 == shmid)
    {
        perror("shmget failed");
        exit(1);
    }

    void *p = shmat(shmid, 0, 0);
    if((void*)-1 == p)
    {
        perror("shmat failed");
        exit(2);
    }

    char x = *(char *)p;
    printf("从共享内存中都取了：%d \n", x);

    if(-1 == shmdt(p))
    {
        perror("shmdt failed");
        exit(3);
    }
    return 0;
}

